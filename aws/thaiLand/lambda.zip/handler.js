
exports.thaiLand = async (event) => {
    console.log('restaurant ThaiLand recieved an order');
    console.log(event);
    return;
}